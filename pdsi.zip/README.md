# `medical-theme`

> TODO: description

## Installation

```
lerna bootstrap
```

## Build

```
gulp build
```

## Watch Changes

```
gulp
```

## Generate Translation

```
gulp translate
```

## Run Minify for Production

```
gulp prod
```
